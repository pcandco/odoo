Go to the menu *Contacts > Configuration > Localization > Import from Geonames*.
In the wizard, select one or several countries and click on the *Import* button.

For each selected country, the wizard will delete all not detected entries, download
the latest version of the list of cities from geonames.org and create new
city zip entries.
