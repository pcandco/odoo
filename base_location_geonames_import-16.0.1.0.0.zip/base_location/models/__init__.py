# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import res_city_zip
from . import res_partner
from . import res_company
from . import res_city
